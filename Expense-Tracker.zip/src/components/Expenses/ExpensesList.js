import React from "react";

import "./ExpensesList.css";
import ExpenseItem from "./ExpenseItem";

const ExpensesList = (props) => {
  if (!props.filteredList.length) {
    return <h2 className="expenses-list__fallback">No expenses found.</h2>;
  }

  if (props.filteredList.length > 0) {
  }

  return (
    <ul className="expenses-list">
      {props.filteredList.map((expense) => (
        <ExpenseItem
            key={expense.id}
            title={expense.title}
            amount={expense.amount}
            date={expense.date}
        />
      ))};
    </ul>
  );
};

export default ExpensesList;
